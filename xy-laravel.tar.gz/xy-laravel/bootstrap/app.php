<?php

use Illuminate\Foundation\Application;
use Illuminate\Foundation\Configuration\Middleware;
use App\Http\Middleware\ResolveTenantFromSubdomain;
use App\Http\Middleware\TenantOwner;

return Application::configure(basePath: dirname(__DIR__))
    ->withRouting(
        web: __DIR__.'/../routes/web.php',
        api: __DIR__.'/../routes/api.php',
        commands: __DIR__.'/../routes/console.php',
        health: '/up',
    )
    ->withMiddleware(function (Middleware $middleware) {
        $middleware->append(ResolveTenantFromSubdomain::class);

        $middleware->alias([
            'tenant.owner' => TenantOwner::class,
        ]);
    })
    ->withExceptions(function ($exceptions) {
        //
    })->create();
